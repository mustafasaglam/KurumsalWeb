<div class="col-lg-4">   
	<aside class="<?php echo iwebtheme_smof_data('sidebar_pos'); ?>-sidebar">
    <?php 
		/* Primary Sidebar */
		dynamic_sidebar('Primary Sidebar');
	?>	
	</aside>
</div>
