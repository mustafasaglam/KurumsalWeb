<?php
/**
 * @package WordPress
 * @subpackage Moderna Theme
 */
?>
<form class="form-search" action="<?php echo home_url(); ?>">
		<input type="text" name="s" id="s" placeholder="<?php echo __('Search','iwebtheme'); ?> ..." class="form-control" />		
</form>

